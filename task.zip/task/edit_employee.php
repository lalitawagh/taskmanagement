<?php 
ob_start();
session_start();
include('config.php');
$sql = 'SELECT * from  tbl_employee where id ='.$_POST['id'];
$employeeresult  = mysqli_query($con, $sql);
$employee = mysqli_fetch_assoc($employeeresult);


?>
<div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
          <form action="" method="POST">
        <div class="modal-header">
          
          <h4 class="modal-title">Edit Employee</h4><button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
            <input type="hidden" name="userid" value="<?php echo $employee['id'];?>">
            <div class="row">
                <div class="col-md-3">
                    <label>Employee Name</label>
                </div>
                <div class="col-md-9">
                    <input type="text" name="name" class="form-control" value="<?php echo $employee['name']?>">
                    <span style="color: red"></span>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-md-3">
                    <label>Employee Email</label>
                </div>
                <div class="col-md-9">
                    <input type="text" name="email" class="form-control" value="<?php echo $employee['email']?>">
                    <span style="color: red"></span>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-md-3">
                    <label>Employee Phone</label>
                </div>
                <div class="col-md-9">
                    <input type="text" name="mobile" class="form-control" value="<?php echo $employee['mobile']?>">
                    <span style="color: red"></span>
                </div>
            </div><br>
            <div class="row">
                <div class="col-md-3">
                    <label>Employee Password</label>
                </div>
                <div class="col-md-9">
                    <input type="text" name="password" class="form-control">
                    <span style="color: red"></span>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <input type="submit" name="update_employee" class="btn btn-info" >
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        </form>
      </div>
      
    </div>