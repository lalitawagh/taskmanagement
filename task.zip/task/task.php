<?php 
ob_start();
session_start();
include('config.php');
$sql = 'SELECT * from  tbl_task';
$taskeresult  = mysqli_query($con, $sql);
// $employeelist = mysqli_fetch_row($employeeresult);
$sql = 'SELECT * from  tbl_employee';
$employeeresult  = mysqli_query($con, $sql);
if(isset($_POST['addtask']))
{
    $sql = "INSERT into tbl_task(`task_name`,`task_date`,`taskpriority`,`empid`,`taskdetail`,`status`) values ('".$_POST['name']."','".$_POST['taskdate']."','".$_POST['taskpriority']."','".$_POST['user']."','".$_POST['taskdetail']."',1)";
    $result = mysqli_query($con, $sql);
    if($result == 1)
    {
        header('location: task.php?msg=1');
    }
}

if(isset($_POST['task_delete']))
{
    $sql= "Delete from tbl_task where id =".$_POST['task_delete'];
    $result = mysqli_query($con, $sql);
     if($result == 1)
    {
        header('location: task.php?msg=2');
    }
}
if(isset($_POST['updatetask']))
{
   
    $sql = 'update tbl_task set task_name="'.$_POST['name'].'", task_date = "'.$_POST['taskdate'].'",taskpriority = "'.$_POST['taskpriority'].'",empid = "'.$_POST['user'].'",taskdetail = "'.$_POST['taskdetail'].'" where id = '.$_POST['taskid'];
  
    $result = mysqli_query($con, $sql);
    if($result == 1)
    {
        header('location: task.php?msg=3');
    }
}
error_reporting(0);
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="img/favicon.png">
    <title>Task Management</title>
    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="assets/extra-libs/multicheck/multicheck.css">
    <link href="assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/libs/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
    <link href="dist/css/style.min.css" rel="stylesheet">
    <script src="https://cdn.ckeditor.com/4.5.11/standard/ckeditor.js"></script>
    
</head>

<body>
   
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
   
    <!-- ============================================================== -->
    <div id="main-wrapper">
        
        <?php include('include/header.php');?>
        <?php include('include/sidebar.php');?>
       
        <div class="page-wrapper">
           
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Task List</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Task List</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
           
            <div class="container-fluid">
                <?php if($_GET['msg']== 1){?>
                <div class="alert alert-success alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Success!!! Task Added Successfully</strong>  
                        </div>
                <?php } if($_GET['msg'] == 2){?>
                <div class="alert alert-success alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Success!!! Task Deleted Successfully</strong>  
                        </div>
                <?php } if($_GET['msg'] == 3){?>
                 <div class="alert alert-success alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong>Success!!! Task Updated Successfully</strong>  
                        </div>
                <?php }?>
               
                <form method="post" id="frmfrm" action="">
                    <input type="hidden" name="task_delete" id="task_delete" value=""> 
                    <input type="hidden" name="task_edit" id="task_edit">
                    <input type="hidden" name="deactiveid" id="deactiveid">
                    <input type="hidden" name="activeid" id="activeid">
                    
                </form>
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <span class="card-title">Task List<button type="button" class="btn btn-info margin-5" style="float:right" data-toggle="modal" data-target="#myModal">Add Task</button><br><br></span>
                                  
                                  
                                <div class="table-responsive">
                                    <table id="zero_config" class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Sr No</th>
                                                <th>User name</th>
                                                <th>Task name</th>
                                                <th>Task Date</th>
                                               
                                                <th>Task Priority</th>
                                                <th>Task Status</th>
                                                <th>Action</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                           <?php $i=1;
                                           for($j=0;$j < mysqli_num_rows($taskeresult); $j++)
                                             {
                                                $dataval = mysqli_fetch_assoc($taskeresult);

                                                $sql = 'select * from tbl_employee where id = '.$dataval['empid'];
                                               
                                                $employeedata = mysqli_query($con, $sql);
                                                $datavalemployee = mysqli_fetch_assoc($employeedata);
                                            
                                            ?>
                                            <tr>
                                                <td><?php echo $i;?></td>
                                                <td><?php echo  $datavalemployee['name'];?></td>
                                                <td><?php echo $dataval['task_name'];?></td>
                                                <td><?php echo $dataval['task_date'];?></td>
                                               
                                                <td><?php echo $dataval['taskpriority'];?></td>
                                                <td><?php if($dataval['status'] == 1){echo 'Pending';}else if($dataval['status'] == 2){echo 'Partial';}else if($dataval['status'] == 3){echo 'Complete';};?></td>
                                                <td><a data-toggle="modal" data-target="#editModal" class="view_edit" data-id="<?php echo $dataval['id'];?>"><i class="fa fa-edit"></i></a>
                                                
                                                <a onclick="delete_record(<?php echo $dataval['id']?>)"><i class="fa fa-trash"></i></a></td>
                                            </tr>
                                            <?php $i++;
                                            }?>
                                        </tbody>
                                        
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
              
            </div>
           
            <footer class="footer text-center">
                All Rights Reserved by Qupo.
            </footer>
          
        </div>
       
    </div>
     <!-- Trigger the modal with a button -->


   <div class="modal" id="editModal" tabindex="-1" role="dialog" data-target="#editModal"></div>
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
          <form action="" method="POST">
        <div class="modal-header">
          
          <h4 class="modal-title">Add Task</h4><button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
            <div class="row">
                <div class="col-md-3">
                    <label>User</label>
                </div>
                <div class="col-md-9">
                    <select name="user" class="form-control">
                        <?php
                        for($i = 0; $i < mysqli_num_rows($employeeresult); $i++){ 
                            $datavalemp = mysqli_fetch_assoc($employeeresult);
                            ?>
                            <option value="<?php echo $datavalemp['id']?>"><?php echo $datavalemp['name']?></option>

                        <?php }?>
                    </select>
                    <span style="color: red"></span>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-md-3">
                    <label>Task Name</label>
                </div>
                <div class="col-md-9">
                    <input type="text" name="name" class="form-control">
                    <span style="color: red"></span>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-md-3">
                    <label>Task Priority</label>
                </div>
                <div class="col-md-9">
                    <select class="form-control" name="taskpriority">
                        <option>Select Priority</option>
                        <option value="High">High</option>
                        <option value="Medium">Medium</option>
                        <option value="Low">Low</option>
                    </select>
                    <span style="color: red"></span>
                </div>
            </div>
            <br> <div class="row">
                <div class="col-md-3">
                    <label>Task Detail</label>
                </div>
                <div class="col-md-9">
                    <textarea type="text" name="taskdetail" class="form-control"></textarea> 
                    <span style="color: red"></span>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-md-3">
                    <label>Task deadline date</label>
                </div>
                <div class="col-md-9">
                    <input type="date" name="taskdate" class="form-control">
                    <span style="color: red"></span>
                </div>
            </div>
            <br>
           
            
            
        </div>
        <div class="modal-footer">
            <input type="submit" name="addtask" class="btn btn-info" value="Add">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        </form>
      </div>
      
    </div>
  </div>
  
  
 

   
    <?php include('include/footer.php');?>
    <script src="assets/extra-libs/multicheck/datatable-checkbox-init.js"></script>
    <script src="assets/extra-libs/multicheck/jquery.multicheck.js"></script>
    <script src="assets/extra-libs/DataTables/datatables.min.js"></script>
     <script src="assets/libs/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
    <script>
        $('#zero_config').DataTable();
    </script>
    <script type="text/javascript">
    function delete_record(id)
    {
        if(confirm("Are You Sure ?"))
        {
          $("#task_delete").val(id);
          $("#frmfrm").submit();
        }
        
    }
    
    function edit_record(id)
    {
        $("#employee_edit").val(id);
        $("#frmfrm").attr('action','edit_employee.php');
        $("#frmfrm").submit();
    }
    function deactive(id)
    {
        if(confirm("Are You Sure ?"))
        {
          $("#deactiveid").val(id);
          $("#frmfrm").submit();
        }
    }
    function active(id)
    {
        if(confirm("Are You Sure ?"))
        {
          $("#activeid").val(id);
          $("#frmfrm").submit();
        }
    }
    function addmore()
    {
      
       var html = '<div class="row"><div id="div" class="col-md-10"><input type="time" name="time[]" id="time" class="form-control"></div><div class="col-md-2"><button class="remove btn" name="remove" type="button" >-</button></div></div>';
       $('#timeiddiv').append(html);
     
    }
    $('.timeextra').on('click','.remove',function() {
        $(this).parent().parent().remove();
    });

     $(".view_edit").on("click",function(){

        var id = $(this).attr("data-id");
        
        $.ajax({
                url: 'edit_task.php',
                type: "POST",
                dataType: "html",
                data: {id:id},
           success:function(data)
           {
             
              $("#editModal").append(data);
           },
           beforeSend:function()
           {
           $("#editModal").html("");
           }
        }); 
     })
    
    </script>
