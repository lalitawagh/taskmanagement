<?php 
ob_start();
session_start();
include('config.php');
$sql = 'SELECT * from  tbl_task where id ='.$_POST['id'];
$taskresult  = mysqli_query($con, $sql);
$task= mysqli_fetch_assoc($taskresult);


$sql = 'SELECT * from  tbl_employee';
$employeeresult  = mysqli_query($con, $sql);

?>
  <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
          <form action="" method="POST">
        <div class="modal-header">
          
          <h4 class="modal-title">Edit Task</h4><button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
             <input type="hidden" name="taskid" value="<?php echo $task['id'];?>">
             <div class="row">
                <div class="col-md-3">
                    <label>User</label>
                </div>
                <div class="col-md-9">
                    <select name="user" class="form-control">
                        <?php
                        for($i = 0; $i < mysqli_num_rows($employeeresult); $i++){ 
                            $datavalemp = mysqli_fetch_assoc($employeeresult);
                            ?>
                            <option value="<?php echo $datavalemp['id']?>" <?php if($task['empid'] == $datavalemp['id']){echo 'selected';}?>><?php echo $datavalemp['name']?></option>

                        <?php }?>
                    </select>
                    <span style="color: red"></span>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-md-3">
                    <label>Task Name</label>
                </div>
                <div class="col-md-9">
                    <input type="text" name="name" class="form-control" value="<?php echo $task['task_name']?>">
                    <span style="color: red"></span>
                </div>
            </div>
            <br> <div class="row">
                <div class="col-md-3">
                    <label>Task Priority</label>
                </div>
                <div class="col-md-9">
                    <select class="form-control" name="taskpriority">
                        <option>Select Priority</option>
                        <option value="High" <?php if($task['taskpriority'] == "High"){echo 'selected';}?>>High</option>
                        <option value="Medium"  <?php if($task['taskpriority'] == "Medium"){echo 'selected';}?>>Medium</option>
                        <option value="Low"  <?php if($task['taskpriority'] == "Low"){echo 'selected';}?>>Low</option>
                    </select>
                    <span style="color: red"></span>
                </div>
            </div><br>
            <div class="row">
                <div class="col-md-3">
                    <label>Task Detail</label>
                </div>
                <div class="col-md-9">
                    <textarea type="text" name="taskdetail" class="form-control" ><?php echo $task['taskdetail']?></textarea> 
                    <span style="color: red"></span>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-md-3">
                    <label>Task deadline date</label>
                </div>
                <div class="col-md-9">
                    <input type="date" name="taskdate" class="form-control" value="<?php echo $task['task_date']?>">
                    <span style="color: red"></span>
                </div>
            </div>
            <br>
            
        <div class="modal-footer">
            <input type="submit" name="updatetask" class="btn btn-info" value="Add">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        </form>
      </div>
      
    </div>