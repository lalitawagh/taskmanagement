<?php
ob_start();
session_start();
if($_SESSION['usertype'] == 'admin')
{
	session_destroy();
	header('location: index.php');
}else
{
	session_destroy();
	header('location: user/index.php');
}
?>
